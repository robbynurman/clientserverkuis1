<?php
define("DB_HOST","localhost");
define("DB_USER","id10772562_robbynurman");
define("DB_PASSWORD","root1234");
define("DB_NAME","id10772562_robby");

// echo DB_HOST;
